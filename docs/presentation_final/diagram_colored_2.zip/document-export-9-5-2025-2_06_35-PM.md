# Star Tracker Simulation Pipeline Flow Chart



